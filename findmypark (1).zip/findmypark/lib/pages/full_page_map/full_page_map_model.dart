import '/flutter_flow/flutter_flow_util.dart';
import 'full_page_map_widget.dart' show FullPageMapWidget;
import 'package:flutter/material.dart';

class FullPageMapModel extends FlutterFlowModel<FullPageMapWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
