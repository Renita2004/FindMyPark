import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'accessible_spots_widget.dart' show AccessibleSpotsWidget;
import 'package:flutter/material.dart';

class AccessibleSpotsModel extends FlutterFlowModel<AccessibleSpotsWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
