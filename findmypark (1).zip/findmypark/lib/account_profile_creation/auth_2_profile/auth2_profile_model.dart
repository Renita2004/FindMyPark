import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'auth2_profile_widget.dart' show Auth2ProfileWidget;
import 'package:flutter/material.dart';

class Auth2ProfileModel extends FlutterFlowModel<Auth2ProfileWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
