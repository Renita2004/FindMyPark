// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:url_launcher/url_launcher.dart';

Future newCustomAction() async {
  // i want to open a google maps naviagtion url with my longitude and lat points from a variable

  double latitude = 37.7749;
  double longitude = -122.4194;

  String url =
      'https://www.google.com/maps/dir/?api=1&destination=$latitude,$longitude';

  Uri uri = Uri.parse(url);
  if (await launchUrl(uri)) {
    await launchUrl(uri, mode: LaunchMode.externalApplication);
  } else {
    throw 'Could not launch $url';
  }
}
