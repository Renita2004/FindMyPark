// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart';
import '/custom_code/widgets/parking_spot_details.dart';

class InteractiveOverlay extends StatefulWidget {
  const InteractiveOverlay({
    super.key,
    this.width,
    this.height,
    this.mapWidth = 1000, // Fixed map width
    this.mapHeight = 1000, // Fixed map height
    this.mapImage,
  });

  final double? width;
  final double? height;
  final double? mapWidth;
  final double? mapHeight;
  final String? mapImage;

  @override
  State<InteractiveOverlay> createState() => _InteractiveOverlayState();
}

class _InteractiveOverlayState extends State<InteractiveOverlay> {
  List<Map<String, dynamic>> parkingSpots = [];

  @override
  void initState() {
    super.initState();
    _fetchParkingSpots();
  }

  Future<void> _fetchParkingSpots() async {
    try {
      QuerySnapshot snapshot =
          await FirebaseFirestore.instance.collection('parkingSpots').get();

      setState(() {
        parkingSpots = snapshot.docs.map((doc) {
          var data = doc.data() as Map<String, dynamic>;
          return {
            "ID": data["ID"] ?? doc.id,
            "x": (data["x"] ?? 0).toDouble(),
            "y": (data["y"] ?? 0).toDouble(),
            "isOccupied": data["isOccupied"] ?? false,
            "handicapped": data["handicapped"] ?? false,
          };
        }).toList();
      });
    } catch (e) {
      debugPrint("Error fetching parking spots: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          double screenWidth = constraints.maxWidth;
          double screenHeight = constraints.maxHeight;

          // Maintain aspect ratio to ensure full image is visible
          double aspectRatio = widget.mapWidth! / widget.mapHeight!;
          double scaledMapWidth = screenWidth;
          double scaledMapHeight = screenWidth / aspectRatio;

          // If the calculated height exceeds the screen height, adjust width instead
          if (scaledMapHeight > screenHeight) {
            scaledMapHeight = screenHeight;
            scaledMapWidth = screenHeight * aspectRatio;
          }

          double scaleFactor = scaledMapWidth / widget.mapWidth!;

          return SizedBox(
            width: screenWidth,
            height: screenHeight,
            child: InteractiveViewer(
              panEnabled: true,
              minScale: 1.0,
              maxScale: 3.0,
              child: Center(
                child: SizedBox(
                  width: scaledMapWidth,
                  height: scaledMapHeight,
                  child: Stack(
                    children: [
                      // Map Image
                      Positioned.fill(
                        child: Image.network(
                          widget.mapImage!,
                          fit: BoxFit.contain, // Ensures full image visibility
                        ),
                      ),

                      // Parking Spot Markers
                      ...parkingSpots.map((spot) {
                        double left = (spot['x'] / 1000) * scaledMapWidth;
                        double top = (spot['y'] / 1000) * scaledMapHeight;

                        return Positioned(
                          left: left,
                          top: top,
                          child: GestureDetector(
                            onTap: () {
                              showModalBottomSheet(
                                context: context,
                                builder: (context) {
                                  return ParkingSpotDetails(
                                    spotId: spot['ID'],
                                    isAvailable: !spot['isOccupied'],
                                    isAccessible: spot['handicapped'],
                                  );
                                },
                              );
                            },
                            child: Transform.scale(
                              scale:
                                  scaleFactor, // Scale markers proportionally
                              child: Container(
                                width: 28,
                                height: 28,
                                decoration: BoxDecoration(
                                  color: spot['isOccupied']
                                      ? Colors.red
                                      : Colors.green,
                                  shape: BoxShape.circle,
                                  border:
                                      Border.all(color: Colors.white, width: 2),
                                ),
                              ),
                            ),
                          ),
                        );
                      }).toList(),
                    ],
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
