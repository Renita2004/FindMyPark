// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:cloud_firestore/cloud_firestore.dart'; // Firebase Firestore Import

class InteractiveMap extends StatefulWidget {
  const InteractiveMap({
    super.key,
    this.width,
    this.height,
    this.mapWidth,
    this.mapHeight,
    this.mapImage,
  });

  final double? width;
  final double? height;
  final double? mapWidth;
  final double? mapHeight;
  final String? mapImage;

  @override
  State<InteractiveMap> createState() => _InteractiveMapState();
}

class _InteractiveMapState extends State<InteractiveMap> {
  List<Map<String, dynamic>> parkingSpots = [];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Stack(
        children: [
          Image.network(
            widget.mapImage!,
            width: widget.mapWidth ?? 500,
            height: widget.mapHeight ?? 500,
            fit: BoxFit.contain,
          ),
          Positioned(
            left: 100, // Static X position
            top: 200, // Static Y position
            child: GestureDetector(
              onTap: () => print("Parking spot tapped!"),
              child: Container(
                width: 20,
                height: 20,
                decoration: BoxDecoration(
                  color: Colors.blue,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.white, width: 2),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
