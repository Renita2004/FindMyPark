// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/custom_code/actions/index.dart'; // Imports custom actions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

class ParkingSpotDetails extends StatefulWidget {
  const ParkingSpotDetails({
    super.key,
    this.width,
    this.height,
    this.spotId,
    this.isAvailable,
    this.isAccessible,
  });

  final double? width;
  final double? height;
  final String? spotId;
  final bool? isAvailable;
  final bool? isAccessible;

  @override
  State<ParkingSpotDetails> createState() => _ParkingSpotDetailsState();
}

class _ParkingSpotDetailsState extends State<ParkingSpotDetails> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: FlutterFlowTheme.of(context).secondaryBackground,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Spot ID Header
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: Colors.blue,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Center(
              child: Text(
                '${widget.spotId ?? "Unknown"}', // Prevents null errors
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
          SizedBox(height: 16),

          // Status Row
          Row(
            children: [
              Text(
                'Status',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(width: 12),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: widget.isAvailable! ? Colors.green : Colors.red,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  widget.isAvailable! ? 'Available' : 'Not Available',
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
          SizedBox(height: 12),

          // Accessibility Row
          Row(
            children: [
              Text(
                'Accessible',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
              SizedBox(width: 12),
              Icon(
                Icons.accessible,
                color: (widget.isAccessible ?? false)
                    ? Colors.blue
                    : Colors.grey, // Fixed null safety
                size: 24,
              ),
            ],
          ),

          SizedBox(height: 16),
          Align(
            alignment: Alignment.centerRight,
            child: ElevatedButton(
              onPressed: () => Navigator.pop(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: FlutterFlowTheme.of(context).primary,
              ),
              child: Text('Close'),
            ),
          ),
        ],
      ),
    );
  }
}
