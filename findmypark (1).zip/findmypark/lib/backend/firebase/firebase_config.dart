import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyADX75kSafvrStSPVC9E5FaF6X6-uwHE78",
            authDomain: "findmypark-758a1.firebaseapp.com",
            projectId: "findmypark-758a1",
            storageBucket: "findmypark-758a1.firebasestorage.app",
            messagingSenderId: "1079960709857",
            appId: "1:1079960709857:web:62e4271a59cb1ba3ae25a0"));
  } else {
    await Firebase.initializeApp();
  }
}
