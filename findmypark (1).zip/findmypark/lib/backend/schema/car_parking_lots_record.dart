import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CarParkingLotsRecord extends FirestoreRecord {
  CarParkingLotsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "isOpen" field.
  bool? _isOpen;
  bool get isOpen => _isOpen ?? false;
  bool hasIsOpen() => _isOpen != null;

  // "CarParkLots" field.
  String? _carParkLots;
  String get carParkLots => _carParkLots ?? '';
  bool hasCarParkLots() => _carParkLots != null;

  void _initializeFields() {
    _isOpen = snapshotData['isOpen'] as bool?;
    _carParkLots = snapshotData['CarParkLots'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('CarParkingLots');

  static Stream<CarParkingLotsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CarParkingLotsRecord.fromSnapshot(s));

  static Future<CarParkingLotsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CarParkingLotsRecord.fromSnapshot(s));

  static CarParkingLotsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CarParkingLotsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CarParkingLotsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CarParkingLotsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CarParkingLotsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CarParkingLotsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCarParkingLotsRecordData({
  bool? isOpen,
  String? carParkLots,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'isOpen': isOpen,
      'CarParkLots': carParkLots,
    }.withoutNulls,
  );

  return firestoreData;
}

class CarParkingLotsRecordDocumentEquality
    implements Equality<CarParkingLotsRecord> {
  const CarParkingLotsRecordDocumentEquality();

  @override
  bool equals(CarParkingLotsRecord? e1, CarParkingLotsRecord? e2) {
    return e1?.isOpen == e2?.isOpen && e1?.carParkLots == e2?.carParkLots;
  }

  @override
  int hash(CarParkingLotsRecord? e) =>
      const ListEquality().hash([e?.isOpen, e?.carParkLots]);

  @override
  bool isValidKey(Object? o) => o is CarParkingLotsRecord;
}
