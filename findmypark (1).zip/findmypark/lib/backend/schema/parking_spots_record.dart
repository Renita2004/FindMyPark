import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ParkingSpotsRecord extends FirestoreRecord {
  ParkingSpotsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "ID" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  // "x" field.
  double? _x;
  double get x => _x ?? 0.0;
  bool hasX() => _x != null;

  // "y" field.
  double? _y;
  double get y => _y ?? 0.0;
  bool hasY() => _y != null;

  // "handicapped" field.
  bool? _handicapped;
  bool get handicapped => _handicapped ?? false;
  bool hasHandicapped() => _handicapped != null;

  // "isOccupied" field.
  bool? _isOccupied;
  bool get isOccupied => _isOccupied ?? false;
  bool hasIsOccupied() => _isOccupied != null;

  // "isTracking" field.
  bool? _isTracking;
  bool get isTracking => _isTracking ?? false;
  bool hasIsTracking() => _isTracking != null;

  // "lastUpdated" field.
  DateTime? _lastUpdated;
  DateTime? get lastUpdated => _lastUpdated;
  bool hasLastUpdated() => _lastUpdated != null;

  void _initializeFields() {
    _id = snapshotData['ID'] as String?;
    _x = castToType<double>(snapshotData['x']);
    _y = castToType<double>(snapshotData['y']);
    _handicapped = snapshotData['handicapped'] as bool?;
    _isOccupied = snapshotData['isOccupied'] as bool?;
    _isTracking = snapshotData['isTracking'] as bool?;
    _lastUpdated = snapshotData['lastUpdated'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('parkingSpots');

  static Stream<ParkingSpotsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ParkingSpotsRecord.fromSnapshot(s));

  static Future<ParkingSpotsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ParkingSpotsRecord.fromSnapshot(s));

  static ParkingSpotsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ParkingSpotsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ParkingSpotsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ParkingSpotsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ParkingSpotsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ParkingSpotsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createParkingSpotsRecordData({
  String? id,
  double? x,
  double? y,
  bool? handicapped,
  bool? isOccupied,
  bool? isTracking,
  DateTime? lastUpdated,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'ID': id,
      'x': x,
      'y': y,
      'handicapped': handicapped,
      'isOccupied': isOccupied,
      'isTracking': isTracking,
      'lastUpdated': lastUpdated,
    }.withoutNulls,
  );

  return firestoreData;
}

class ParkingSpotsRecordDocumentEquality
    implements Equality<ParkingSpotsRecord> {
  const ParkingSpotsRecordDocumentEquality();

  @override
  bool equals(ParkingSpotsRecord? e1, ParkingSpotsRecord? e2) {
    return e1?.id == e2?.id &&
        e1?.x == e2?.x &&
        e1?.y == e2?.y &&
        e1?.handicapped == e2?.handicapped &&
        e1?.isOccupied == e2?.isOccupied &&
        e1?.isTracking == e2?.isTracking &&
        e1?.lastUpdated == e2?.lastUpdated;
  }

  @override
  int hash(ParkingSpotsRecord? e) => const ListEquality().hash([
        e?.id,
        e?.x,
        e?.y,
        e?.handicapped,
        e?.isOccupied,
        e?.isTracking,
        e?.lastUpdated
      ]);

  @override
  bool isValidKey(Object? o) => o is ParkingSpotsRecord;
}
