import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ParkingspotsRecord extends FirestoreRecord {
  ParkingspotsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "id" field.
  String? _id;
  String get id => _id ?? '';
  bool hasId() => _id != null;

  // "x" field.
  double? _x;
  double get x => _x ?? 0.0;
  bool hasX() => _x != null;

  // "y" field.
  double? _y;
  double get y => _y ?? 0.0;
  bool hasY() => _y != null;

  // "available" field.
  bool? _available;
  bool get available => _available ?? false;
  bool hasAvailable() => _available != null;

  void _initializeFields() {
    _id = snapshotData['id'] as String?;
    _x = castToType<double>(snapshotData['x']);
    _y = castToType<double>(snapshotData['y']);
    _available = snapshotData['available'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('parkingspots');

  static Stream<ParkingspotsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ParkingspotsRecord.fromSnapshot(s));

  static Future<ParkingspotsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ParkingspotsRecord.fromSnapshot(s));

  static ParkingspotsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ParkingspotsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ParkingspotsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ParkingspotsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ParkingspotsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ParkingspotsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createParkingspotsRecordData({
  String? id,
  double? x,
  double? y,
  bool? available,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'id': id,
      'x': x,
      'y': y,
      'available': available,
    }.withoutNulls,
  );

  return firestoreData;
}

class ParkingspotsRecordDocumentEquality
    implements Equality<ParkingspotsRecord> {
  const ParkingspotsRecordDocumentEquality();

  @override
  bool equals(ParkingspotsRecord? e1, ParkingspotsRecord? e2) {
    return e1?.id == e2?.id &&
        e1?.x == e2?.x &&
        e1?.y == e2?.y &&
        e1?.available == e2?.available;
  }

  @override
  int hash(ParkingspotsRecord? e) =>
      const ListEquality().hash([e?.id, e?.x, e?.y, e?.available]);

  @override
  bool isValidKey(Object? o) => o is ParkingspotsRecord;
}
