import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _heartease =
          latLngFromString(prefs.getString('ff_heartease')) ?? _heartease;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _spotAccessible = false;
  bool get spotAccessible => _spotAccessible;
  set spotAccessible(bool value) {
    _spotAccessible = value;
  }

  LatLng? _heartease = LatLng(10.64068108565765, -61.39712333793737);
  LatLng? get heartease => _heartease;
  set heartease(LatLng? value) {
    _heartease = value;
    value != null
        ? prefs.setString('ff_heartease', value.serialize())
        : prefs.remove('ff_heartease');
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
