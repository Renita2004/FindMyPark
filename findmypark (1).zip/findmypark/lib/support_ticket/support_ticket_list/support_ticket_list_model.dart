import '/flutter_flow/flutter_flow_util.dart';
import '/index.dart';
import 'support_ticket_list_widget.dart' show SupportTicketListWidget;
import 'package:flutter/material.dart';

class SupportTicketListModel extends FlutterFlowModel<SupportTicketListWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
