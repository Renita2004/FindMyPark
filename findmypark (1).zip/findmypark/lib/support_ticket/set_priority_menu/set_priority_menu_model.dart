import '/flutter_flow/flutter_flow_util.dart';
import 'set_priority_menu_widget.dart' show SetPriorityMenuWidget;
import 'package:flutter/material.dart';

class SetPriorityMenuModel extends FlutterFlowModel<SetPriorityMenuWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
